package com.example.login.Helper;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class base_de_datos {
    // Añadir datos
    private DatabaseReference mDatabase;

    private void readData(String title) {
        mDatabase.child(title).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Verificar si el DataSnapshot tiene datos
                if (dataSnapshot.exists()) {
                    // Iterar sobre los hijos de Romulus
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        String key = snapshot.getKey();
                        String cine = snapshot.child("cine").getValue(String.class);
                        String horarios = snapshot.child("horarios").getValue(String.class);
                        String precio = snapshot.child("precio").getValue(String.class);

                        // Mostrar los datos en la consola
                        Log.d("Firebase", "Nombre del cine: " + cine);
                        Log.d("Firebase", "Horarios: " + horarios);
                        Log.d("Firebase", "Precio: " + precio);
                    }
                } else {
                    Log.d("Firebase", "No se encontraron datos.");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Manejar errores
                Log.e("Firebase", "Error al leer datos.", databaseError.toException());
            }
        });
    }

    private void addData() {
        // Datos a añadir
        Map<String, Object> alienData = new HashMap<>();

        Map<String, String> andino = new HashMap<>();
        andino.put("cine", "Andino");
        andino.put("horarios", "3:00pm");
        andino.put("precio", "12mil");

        Map<String, String> americas = new HashMap<>();
        americas.put("cine", "americas");
        americas.put("horarios", "12:00pm 02:05pm");
        americas.put("precio", "12mil");

        // Añadir subnodos
        alienData.put("Andino", andino);
        alienData.put("americas", americas);

        // Añadir datos a Firebase
        mDatabase.child("name").setValue(alienData)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Log.d("Firebase", "Datos añadidos exitosamente.");
                        } else {
                            Log.e("Firebase", "Error al añadir datos.", task.getException());
                        }
                    }
                });
    }
}
