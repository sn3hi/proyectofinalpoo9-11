package com.example.login.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.login.Adapter.MovieAdapter;
import com.example.login.Adapter.MovieAdapter2;
import com.example.login.Helper.Movie;
import com.example.login.R;
import com.example.login.activity.Home;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class user extends AppCompatActivity {
    Button home, person, notification;
    private static final String TAG = "DisplayActivity";
    private static final String PREFS_NAME = "MyPrefs";
    private static final String TITLES_KEY = "titles";
    private DatabaseReference rootdatabaseref;
    private RecyclerView recyclerView4;
    private MovieAdapter2 movieAdapter2;
    private List<Movie> movieList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            home = findViewById(R.id.home);
            person = findViewById(R.id.person);
            notification = findViewById(R.id.notification);


            SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            Set<String> titles = sharedPreferences.getStringSet(TITLES_KEY, new HashSet<>());

            // Imprimir los títulos en Logcat
            for (String title : titles) {
                Log.d(TAG, "Título guardado: " + title);
            }

            recyclerView4 = findViewById(R.id.recyclerView4);
            recyclerView4.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

            movieList = new ArrayList<>();
            movieAdapter2 = new MovieAdapter2(this, movieList);
            recyclerView4.setAdapter(movieAdapter2);
            home.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(user.this, Home.class);
                    startActivity(intent);
                    finish();
                }
            });
            person.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(user.this,user.class);
                    startActivity(intent);
                    finish();
                }
            });
            notification.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(user.this,notification.class);
                    startActivity(intent);
                    finish();
                }
            });

            loadMoviesFromFirebase();
            return insets;
        });
    }
    private void loadMoviesFromFirebase() {
        // Obtener la instancia de SharedPreferences
        final SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final Set<String> titlesSet = sharedPreferences.getStringSet(TITLES_KEY, new HashSet<>());

        // Crear una lista mutable a partir del conjunto de títulos
        final List<String> titles = new ArrayList<>(titlesSet);

        DatabaseReference movieRef = FirebaseDatabase.getInstance().getReference("movie_titles");

        movieRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                movieList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String title = snapshot.child("title").getValue(String.class);
                    String imageUrl = snapshot.child("image").getValue(String.class);


                    // Solo agregar a la lista si el título está en el conjunto de títulos guardados
                    if (title != null && titles.contains(title.toLowerCase())) {
                        Movie movie = new Movie(title, imageUrl);
                        movieList.add(movie);
                    }
                }
                movieAdapter2.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Manejo de errores
                Log.e(TAG, "Database error: " + databaseError.getMessage());
            }
        });
    }
}