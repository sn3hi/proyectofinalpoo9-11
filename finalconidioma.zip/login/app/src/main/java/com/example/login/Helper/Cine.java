package com.example.login.Helper;

public class Cine {
    private String cine;
    private String horarios;
    private String precio;

    public Cine() {
        // Default constructor required for calls to DataSnapshot.getValue(Cine.class)
    }

    public Cine(String cine, String horarios, String precio) {
        this.cine = cine;
        this.horarios = horarios;
        this.precio = precio;
    }

    public String getCine() {
        return cine;
    }

    public void setCine(String cine) {
        this.cine = cine;
    }

    public String getHorarios() {
        return horarios;
    }

    public void setHorarios(String horarios) {
        this.horarios = horarios;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }
}

