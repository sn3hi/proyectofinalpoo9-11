package com.example.login.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.login.activity.Home;
import com.example.login.Helper.Movie;
import com.example.login.R;
import com.example.login.activity.data_activity;

import java.util.List;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {

    private Context context;
    private List<Movie> movieList;

    public MovieAdapter(Context context, List<Movie> movieList) {
        this.context = context;
        this.movieList = movieList;
    }




    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_movie, parent, false);
        return new MovieViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder holder, int position) {
        Movie movie = movieList.get(position);
        holder.movieTitle.setText(movie.getTitle());
        Glide.with(context).load(movie.getImageUrl()).into(holder.movieImage);

        // Configura el click listener
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Crear el Intent para iniciar data_activity
                Intent intent = new Intent(context, data_activity.class);
                // Pasar el título y la URL de la imagen a la nueva actividad
                intent.putExtra("title", movie.getTitle());
                intent.putExtra("imageUrl", movie.getImageUrl());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return movieList.size();
    }

    public void updateMovieList(List<Movie> newMovieList) {
        movieList = newMovieList;
        notifyDataSetChanged();  // Notifica al adaptador que los datos han cambiado
    }

    public static class MovieViewHolder extends RecyclerView.ViewHolder {

        ImageView movieImage;
        TextView movieTitle;

        public MovieViewHolder(@NonNull View itemView) {
            super(itemView);
            movieImage = itemView.findViewById(R.id.pic);
            movieTitle = itemView.findViewById(R.id.titletext);
        }
    }
}
