package com.example.login.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.login.Adapter.CineAdapter;
import com.example.login.Adapter.CineAdapter2;
import com.example.login.Helper.Cine;
import com.example.login.Helper.Cine2;
import com.example.login.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class data_activity extends AppCompatActivity {
    private DatabaseReference mDatabase;
    private RecyclerView recyclerView2;
    private RecyclerView recyclerView3;

    private CineAdapter cineAdapter;
    private CineAdapter2 cineAdapter2;
    private List<Cine> cineList;
    private List<Cine2> cineList2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_data);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            recyclerView2 = findViewById(R.id.recyclerView2);
            recyclerView2.setLayoutManager(new LinearLayoutManager(this));

            recyclerView3 = findViewById(R.id.recyclerView3);
            recyclerView3.setLayoutManager(new LinearLayoutManager(this));

            // Inicializa Firebase
            mDatabase = FirebaseDatabase.getInstance().getReference();

            // Obtener los datos pasados por el Intent
            Intent intent = getIntent();
            String title = intent.getStringExtra("title");
            String imageUrl = intent.getStringExtra("imageUrl");

            cineList = new ArrayList<>();
            cineAdapter = new CineAdapter(cineList, cine -> {
                // Buscar la URL en Firebase y abrirla en un navegador
                mDatabase.child("movie_titles")
                        .orderByChild("title")
                        .equalTo(title)
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    for (DataSnapshot movieSnapshot : dataSnapshot.getChildren()) {
                                        String url = movieSnapshot.child("url").getValue(String.class);
                                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                                        startActivity(browserIntent);
                                    }
                                } else {
                                    Log.d("Movie URL", "No se encontró la película con el título: " + title);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Log.e("Movie URL", "Error al obtener la URL: " + databaseError.getMessage());
                            }
                        });
            });
            cineList2 = new ArrayList<>();
            cineAdapter2 = new CineAdapter2(cineList2, cine -> {
                // Buscar la URL en Firebase y abrirla en un navegador
                mDatabase.child("titles_cinepolis")
                        .orderByChild("title")
                        .equalTo(title)
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    for (DataSnapshot movieSnapshot : dataSnapshot.getChildren()) {
                                        String url2 = movieSnapshot.child("url").getValue(String.class);
                                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url2));
                                        startActivity(browserIntent);
                                    }
                                } else {
                                    Log.d("Movie URL", "No se encontró la película con el título: " + title);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Log.e("Movie URL", "Error al obtener la URL: " + databaseError.getMessage());
                            }
                        });
            });
            recyclerView2.setAdapter(cineAdapter);


            recyclerView3.setAdapter(cineAdapter2);

            // Leer datos
            readData(title);

            // Actualizar la UI con los datos de la película seleccionada
            ImageView movieImageView = findViewById(R.id.bigimage);

            // Cargar la imagen con Glide
            Glide.with(this)
                    .load(imageUrl)
                    .placeholder(R.drawable.cine)  // Imagen por defecto (opcional)
                    .error(R.drawable.cine2)        // Imagen en caso de error (opcional)
                    .into(movieImageView);

            // Configurar el botón de retroceso
            ImageView backButton = findViewById(R.id.back);
            ImageView heartButton = findViewById(R.id.heart);
            backButton.setOnClickListener(ve -> finish());  // Finaliza la actividad actual y regresa a la anterior (Home)


            // Configurar el listener para el botón
            heartButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Obtener la instancia de SharedPreferences
                    SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);

                    // Obtener el Set actual de títulos guardados, si existen
                    Set<String> titles = sharedPreferences.getStringSet("titles", new HashSet<>());

                    // Crear una nueva copia del Set (necesario porque el Set obtenido es inmutable)
                    Set<String> newTitles = new HashSet<>(titles);

                    // Verificar si el título ya está guardado
                    if (newTitles.contains(title)) {
                        // Si está guardado, eliminarlo
                        newTitles.remove(title);
                        heartButton.setImageResource(R.drawable.heart); // Cambiar el ícono al ícono vacío
                    } else {
                        // Si no está guardado, agregarlo
                        newTitles.add(title);
                        heartButton.setImageResource(R.drawable.full_heart); // Cambiar el ícono al ícono lleno
                    }

                    // Guardar el Set actualizado en SharedPreferences
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putStringSet("titles", newTitles);
                    editor.apply(); // o editor.commit() si prefieres hacer la operación de forma síncrona
                }
            });

            // Verificar si el título ya está guardado y actualizar el estado del botón
            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
            Set<String> titles = sharedPreferences.getStringSet("titles", new HashSet<>());

            if (titles.contains(title)) {
                heartButton.setImageResource(R.drawable.full_heart); // Cambiar el ícono al ícono lleno
            } else {
                heartButton.setImageResource(R.drawable.heart); // Cambiar el ícono al ícono vacío
            }

            return insets;
        });
    }

    private void readData(String title) {
        mDatabase.child(title).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                cineList.clear();
                cineList2.clear(); // Limpiar la lista existente

                // Verificar si el DataSnapshot tiene datos
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        String cine = " " + snapshot.child("cine").getValue(String.class);
                        String horarios = " " + snapshot.child("horarios").getValue(String.class);
                        String precio = " " + snapshot.child("precio").getValue(String.class);

                        if ((" Cinépolis Diverplaza".equals(cine)) ||
                                (" Cinépolis Hayuelos Colombia".equals(cine)) ||
                                (" Cinépolis Mallplaza".equals(cine)) ||
                                (" Cinépolis VIP Plaza Claro".equals(cine))) {
                            cineList2.add(new Cine2(cine, horarios, precio));
                            cineAdapter2.notifyDataSetChanged();
                        } else {
                            cineList.add(new Cine(cine, horarios, precio));
                            cineAdapter.notifyDataSetChanged();
                        }
                    }
                } else {
                    Log.d("Firebase", "No se encontraron datos.");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("Firebase", "Error al leer datos.", databaseError.toException());
            }
        });
    }
}