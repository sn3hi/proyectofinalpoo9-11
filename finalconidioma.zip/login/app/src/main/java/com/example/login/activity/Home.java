package com.example.login.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.login.Adapter.MovieAdapter;
import com.example.login.Helper.Movie;
import com.example.login.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Home extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private DatabaseReference databaseReference;
    Button home, person, notification;

    private DatabaseReference rootdatabaseref;
    private RecyclerView recyclerView;
    private MovieAdapter movieAdapter;
    private List<Movie> movieList;
    private SearchView search;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);



            // Inicializa Firebase Realtime Database
            databaseReference = FirebaseDatabase.getInstance().getReference("movie_titles");

            recyclerView = findViewById(R.id.recyclerView);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

            movieList = new ArrayList<>();
            movieAdapter = new MovieAdapter(this, movieList);
            recyclerView.setAdapter(movieAdapter);

            search = findViewById(R.id.search);



            search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String s) {
                    search(s);
                    return true;
                }
            });

            // Cargar datos desde Firebase
            loadMoviesFromFirebase();


            
            home = findViewById(R.id.home);
            person = findViewById(R.id.person);
            notification = findViewById(R.id.notification);
            home.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Home.this,Home.class);
                    startActivity(intent);
                    finish();
                }
            });
            person.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Home.this, user.class);
                    startActivity(intent);
                    finish();
                }
            });
            notification.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Home.this, com.example.login.activity.notification.class);
                    startActivity(intent);
                    finish();
                }
            });



            return insets;
        });

    }

    private void search(String s) {
        ArrayList<Movie> filteredList = new ArrayList<>();
        for (Movie obj : movieList) {
            if (obj.getTitle().toLowerCase().contains(s.toLowerCase())) {
                filteredList.add(obj);
            }
        }
        movieAdapter.updateMovieList(filteredList);
    }

    private void loadMoviesFromFirebase() {
        DatabaseReference movieRef = FirebaseDatabase.getInstance().getReference("movie_titles");

        movieRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                movieList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String title = snapshot.child("title").getValue(String.class);
                    String imageUrl = snapshot.child("image").getValue(String.class);
                    Movie movie = new Movie(title, imageUrl);
                    movieList.add(movie);
                }
                movieAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Manejo de errores
            }
        });
    }


}