package com.example.login.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.login.R;
import com.example.login.activity.Home;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.internal.ILocationSourceDelegate;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;

public class notification extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap myMap;

    Button home, person, notification;
    private EditText editTextMovie, editTextUsername;
    private Button enviarInfo;
    private DatabaseReference rootdatabaseref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_notification);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            home = findViewById(R.id.home);
            person = findViewById(R.id.person);
            notification = findViewById(R.id.notification);

            home.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(notification.this, Home.class);
                    startActivity(intent);
                    finish();
                }
            });
            person.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(notification.this, user.class);
                    startActivity(intent);
                    finish();
                }
            });
            notification.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(notification.this, notification.class);
                    startActivity(intent);
                    finish();
                }
            });

            return insets;
        });
    }


    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        /*
        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        googleMap.setMyLocationEnabled(true);

        fusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location!=null){
                    LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                    googleMap.addMarker(new MarkerOptions().position(userLocation).title("Tu"));
                }
            }
        });
        */


        myMap = googleMap;
        LatLng bogota = new LatLng(4.7110, -74.0721);
        LatLng andino = new LatLng(4.66697, -74.05262);
        LatLng americas = new LatLng(4.629503, -74.127093);
        LatLng cedritos = new LatLng(4.725902, -74.043817);
        LatLng centrochia = new LatLng(4.863417, -74.040733);
        LatLng centromayor = new LatLng(4.59034, -74.12400);
        LatLng embajador = new LatLng(4.609710, -74.070766);
        LatLng galerias = new LatLng(4.646274, -74.073431);
        LatLng granestacion = new LatLng(4.64687, -74.10316);
        LatLng metropolis = new LatLng(4.678504, -74.084340);
        LatLng nuestrobogota = new LatLng(4.68389, -74.11674);
        LatLng plazacentral = new LatLng(4.633916, -74.108119);
        LatLng portal80 = new LatLng(4.668324, -74.053407);
        LatLng santafe = new LatLng(4.76253, -74.04650);
        LatLng titanplaza = new LatLng(4.693434, -74.078893);
        LatLng hayuelos = new LatLng(4.66423, -74.12960);
        LatLng plazaclaro = new LatLng(4.65168, -74.10583);
        LatLng mallplaza = new LatLng(4.61912, -74.08499);

        myMap.addMarker(new MarkerOptions()
                .position(hayuelos)
                .title("Hayuelos")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
        myMap.addMarker(new MarkerOptions()
                .position(plazaclaro)
                .title("Plaza Claro")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
        myMap.addMarker(new MarkerOptions()
                .position(mallplaza)
                .title("Mallplaza")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));



        myMap.addMarker(new MarkerOptions()
                .position(andino)
                .title("Andino"));
        myMap.addMarker(new MarkerOptions()
                .position(americas)
                .title("Americas"));
        myMap.addMarker(new MarkerOptions()
                .position(cedritos)
                .title("Cedritos"));
        myMap.addMarker(new MarkerOptions()
                .position(centrochia)
                .title("Centro Chia"));
        myMap.addMarker(new MarkerOptions()
                .position(centromayor)
                .title("Centro Mayor"));
        myMap.addMarker(new MarkerOptions()
                .position(embajador)
                .title("Embajador"));
        myMap.addMarker(new MarkerOptions()
                .position(galerias)
                .title("Galerias"));
        myMap.addMarker(new MarkerOptions()
                .position(granestacion)
                .title("Gran Estación"));
        myMap.addMarker(new MarkerOptions()
                .position(metropolis)
                .title("Metropolis"));
        myMap.addMarker(new MarkerOptions()
                .position(nuestrobogota)
                .title("Nuestro Bogotá"));
        myMap.addMarker(new MarkerOptions()
                .position(plazacentral)
                .title("Plaza Central"));
        myMap.addMarker(new MarkerOptions()
                .position(portal80)
                .title("Portal 80"));
        myMap.addMarker(new MarkerOptions()
                .position(santafe)
                .title("Santa Fe"));
        myMap.addMarker(new MarkerOptions()
                .position(titanplaza)
                .title("Titan"));

        float zoomLevel = 11.5f;
        myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(galerias,zoomLevel));

    }

}