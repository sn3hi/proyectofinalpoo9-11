package com.example.login.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.login.Helper.Cine;
import com.example.login.R;

import java.util.List;

public class CineAdapter extends RecyclerView.Adapter<CineAdapter.CineViewHolder> {

    private List<Cine> cineList;
    private OnItemClickListener listener;

    // Interfaz para manejar clics en los elementos del RecyclerView
    public interface OnItemClickListener {
        void onItemClick(Cine cine);
    }

    // Constructor del adaptador
    public CineAdapter(List<Cine> cineList, OnItemClickListener listener) {
        this.cineList = cineList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CineViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cine, parent, false);
        return new CineViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CineViewHolder holder, int position) {
        Cine cine = cineList.get(position);
        holder.clockTextView.setText(cine.getHorarios());
        holder.companyTextView.setText(cine.getCine());
        holder.priceTextView.setText(cine.getPrecio());
        holder.itemView.setOnClickListener(v -> listener.onItemClick(cine));
    }

    @Override
    public int getItemCount() {
        return cineList.size();
    }

    // ViewHolder para el RecyclerView
    public static class CineViewHolder extends RecyclerView.ViewHolder {
        TextView clockTextView;
        TextView companyTextView;
        TextView priceTextView;

        public CineViewHolder(@NonNull View itemView) {
            super(itemView);
            clockTextView = itemView.findViewById(R.id.clock);
            companyTextView = itemView.findViewById(R.id.company);
            priceTextView = itemView.findViewById(R.id.price);
        }
    }
}