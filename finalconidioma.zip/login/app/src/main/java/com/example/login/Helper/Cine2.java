package com.example.login.Helper;

public class Cine2 {
    private String cine;
    private String horarios;
    private String precio;

    public Cine2() {
        // Default constructor required for calls to DataSnapshot.getValue(Cine.class)
    }

    public Cine2(String cine, String horarios, String precio) {
        this.cine = cine;
        this.horarios = horarios;
        this.precio = precio;
    }

    public String getCine() {
        return cine;
    }

    public void setCine(String cine) {
        this.cine = cine;
    }

    public String getHorarios() {
        return horarios;
    }

    public void setHorarios(String horarios) {
        this.horarios = horarios;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }
}